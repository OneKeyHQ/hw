__version__ = "1.0.0"

# fmt: off
MINIMUM_FIRMWARE_VERSION = {
    "1": (1, 8, 0),
    "T": (2, 1, 0),
}
# fmt: on
